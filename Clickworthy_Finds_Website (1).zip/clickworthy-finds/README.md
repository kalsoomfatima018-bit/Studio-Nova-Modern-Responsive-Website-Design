# Clickworthy Finds — Website demo

This is a responsive, static HTML/CSS/JS portfolio demo.

## Preview locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Upload the contents of this folder (not the enclosing folder) to a GitHub repository.
2. Keep `index.html`, `style.css`, `script.js`, and the SVG product illustrations together in the repository root.
3. In Settings → Pages, select `Deploy from a branch`, branch `main`, folder `/(root)`, then Save.

## Before using for a real business or client
- Replace sample product names, prices, descriptions, and illustrations with accurate approved content.
- Replace `hello@example.com` with a real contact method.
- Connect real product pages, checkout, payment, shipping, privacy, returns, and terms as appropriate. This demo does not process orders or payments.
- For affiliate use, add your real approved affiliate URLs and a clear affiliate disclosure; do not imply endorsement or guaranteed results.
- This is a portfolio concept. Describe it honestly as a demo/concept unless you have adapted it for a real client.
